For MNIST dataset, download from <http://yann.lecun.com/exdb/mnist/> and put the standalone files into this folder.
